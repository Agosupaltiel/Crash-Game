
let multiplier = 1.0;
let crashed = false;
let interval;
let crashPoint;
let betPlaced = false;
let cashedOut = false;
let balance = 1000;
let currentBet = 0;

const balanceDisplay = document.getElementById("balance");
const multiplierDisplay = document.getElementById("multiplier");
const statusDisplay = document.getElementById("status");
const cashoutBtn = document.getElementById("cashout");

function updateBalance() {
  balanceDisplay.textContent = `Balance: 💰 ${balance}`;
}

function placeBet() {
  const betInput = document.getElementById("betAmount");
  currentBet = parseInt(betInput.value);

  if (betPlaced || isNaN(currentBet) || currentBet <= 0 || currentBet > balance) {
    statusDisplay.textContent = "Invalid bet amount!";
    return;
  }

  betPlaced = true;
  cashedOut = false;
  crashed = false;
  multiplier = 1.0;
  crashPoint = getRandomCrashPoint();
  statusDisplay.textContent = "Game started!";
  cashoutBtn.disabled = false;
  balance -= currentBet;
  updateBalance();

  interval = setInterval(() => {
    if (crashed) return;
    multiplier += 0.01;
    multiplier = parseFloat(multiplier.toFixed(2));
    multiplierDisplay.textContent = multiplier + "x";

    if (multiplier >= crashPoint) {
      endGame(false);
    }
  }, 100);
}

function cashOut() {
  if (!betPlaced || cashedOut) return;
  cashedOut = true;
  endGame(true);
}

function endGame(success) {
  clearInterval(interval);
  crashed = true;
  cashoutBtn.disabled = true;

  if (success) {
    const winnings = parseFloat((currentBet * multiplier).toFixed(2));
    balance += winnings;
    statusDisplay.textContent = `✅ You cashed out at ${multiplier}x and won ${winnings}!`;
  } else {
    statusDisplay.textContent = `💥 Crashed at ${multiplier}x. You lost ${currentBet}.`;
  }

  updateBalance();

  setTimeout(() => {
    multiplierDisplay.textContent = "1.00x";
    statusDisplay.textContent = "Waiting for next round...";
    betPlaced = false;
    currentBet = 0;
  }, 2500);
}

function getRandomCrashPoint() {
  let r = Math.random();
  return parseFloat((1 + Math.pow(r, 2) * 5).toFixed(2));
}
